<?php
/**
 * Created by PhpStorm.
 * User: alexw
 * Date: 11/21/15
 * Time: 5:07 PM
 */
    namespace xorm\dbms\mysql;
    class Enum implements xorm\interfaces\Field {

    }