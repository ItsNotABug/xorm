<?php

    namespace xorm\dbms;

    class MySQL implements xorm\interfaces\dbms {

        protected static $conn = null;
        protected static $records = array();

        protected static $collection;
        protected static $collection_name;
        protected static $default_data = array();

        protected $data = array();
        protected $new_data = array();
        protected $id = null;

        public static function init($db_host, $db_user, $db_pass, $db_name) {
            //@TODO Add validation & handling for database credentials & connection.
            self::$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
        }

        public function __construct($data=array()) {
            $data = array_merge(static::$default_data, $data);
            foreach($data as $column=>$value) {
                $this->set($column, $value);
            }
            return $this;
        }

        public static function __structure() {
            //fields & indexes are created here. Should there be addField & addIndex methods?
            static::__addField('id', new xorm\dbms\mysql\Integer());
            static::__addIndex('id', new xorm\dbms\mysql\PrimaryKey('id', $auto_increment=true));
        }

        public static function __addField($alias, $field) {
            static::$structure['fields'][$alias] = $field;
        }

        public static function __addIndex($alias, $index) {
            static::$structure['indexes'][$alias] = $index;
        }

        public function get($column) {
            if(isset($this->new_data[$column]))
                return $this->new_data[$column];
            elseif(isset($this->data[$column]))
                return $this->data[$column];

            return false;
        }

        public function getNew($column) {
            if(isset($this->new_data[$column]))
                return $this->new_data[$column];
            return false;
        }

        public function getOriginal($column) {
            if(isset($this->data[$column]))
                return $this->data[$column];
            return false;
        }

        public function set($column, $value) {
            if($this->validate($column,$value))
                $this->new_data[$column] = $value;
            return $this;
        }

        public function setData($data) {
            foreach($data as $column=>$value) {
                $this->set($column, $value);
            }
            return $this;
        }

        public function validate($column, $value) {
            if($column == 'id') {
                throw new XormFatalException('You can not change the ID of an object.');
            }
            elseif(!array_key_exists($column, static::$structure)) {
                throw new XormFatalException('Attempting to set invalidcolumn '.htmlspecialchars($column).' on object '.__CLASS__);
            }
            elseif(!static::$structure[$column]::validate($value)) {
                //this performs type validation, the above method should return an error.
            }
        }
        public function save() {
            if(count($this->new_data)>0 && $this->new_data !== $this->data) {
                $conn = self::$conn;

                $query = 'UPDATE '.static::$collection.' SET ';
                if(is_null($this->id))
                    $query = 'INSERT INTO '.static::$collection;

                foreach($this->new_data as $column=>$value) {
                    $query .= $column.'="'.$conn::real_escape_string($value).'", ';
                }

                $query = substr($query, 0, strlen($query)-2);

                if(!is_null($this->id))
                    $query .= 'WHERE id="'.$conn::real_escape_string($this->id);
                if($conn->query($query)) {
                    $this->data = array_merge($this->data, $this->new_data);
                    $this->new_data = array();

                    if(is_null($this->id)) {
                        $this->id = $conn->insert_id;
                    }

                    $this->records[$this->id] = $this->data;
                    return $this;
                }

                throw new XormException('Record save failed.');
            }
        }

        public function delete() {
            if(!is_null($this->id)) {
                if(self::$conn->query('DELETE FROM '.$this->collection.' WHERE id="'.$this->id.'" LIMIT 1;')) {
                    unset(static::$records[$this->id]);
                    return $this;
                }
                else
                    throw new XormException('Failed to delete record.');
            }
        }

        public static function sLoad($data) {

        }
        public static function sDelete($data) {}
        public static function sUpdate($data, $filters) {}

    }


xorm\dbms\MySQL::init('localhost','test','test','orm_database');