<?php

    namespace xorm;

    class XormException extends Exception {}
    class Object {
        protected $data;
        protected $new_data;

        protected $records;
        protected $collection_name = null;
        protected $structure = array();
        protected $collection = null;

        public function __construct() {

        }

        public function get($id) {

        }

        public function validate() {

        }

        public function getList() {

        }

        public function save() {

        }
    }