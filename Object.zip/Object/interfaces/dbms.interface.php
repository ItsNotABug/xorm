<?php
/**
 * Created by PhpStorm.
 * User: alexw
 * Date: 11/21/15
 * Time: 4:07 PM
 */

    namespace xorm\interfaces;

    interface dbms {
        public function __construct();
        public function get();
        public function set($column, $value);
        public function save();
        public function delete();

        public static function sLoad($data);
        public static function sDelete($data);
        public static function sUpdate($data, $filters);
    }