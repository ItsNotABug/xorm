<?php
/**
 * Created by PhpStorm.
 * User: alexw
 * Date: 11/21/15
 * Time: 5:10 PM
 */

    namespace xorm\interfaces;
    interface Field {
        public static function validate($data);
    }