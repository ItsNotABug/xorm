<?php
/**
 * Created by PhpStorm.
 * User: alexw
 * Date: 11/21/15
 * Time: 4:07 PM
 */

    namespace xorm\interfaces;
    interface object {
        public function __structure();

    }